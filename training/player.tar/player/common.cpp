#include "common.h"
#include <cstdio>

int Common::player(){
    printf("Select the player\n");
    printf("CDP: 1, LP: 2, MP3: 3, Quit: q\n");
    printf("input: "); 
    return 0;
}

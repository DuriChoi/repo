#ifndef _COMMON_H

#define _COMMON_H

class Common{
	public:
		int volUp();
		int volDown();
		int play();
		int pause();
		int stop();
        int player();
};

#endif

#include "myTest.h"

#include <cstdio>
#include <pthread.h>
#include <unistd.h>

static pthread_t pthA ;
static pthread_t pthB ;

static int m_flagDestroy = 0 ;

static void* thFunc_A(void* arg) ;
static void* thFunc_B(void* arg) ;

void* thFunc_A(void* arg)
{
	while(1)
	{
		printf("1\n") ;
		usleep(400000) ;
		printf("2\n") ;
		
		if(m_flagDestroy)
			break ;
	}

	printf("Bye~ thFunc_A()\n") ;
	return NULL ;
}

void* thFunc_B(void* arg)
{
	while(1)
	{
		printf("\t5\n") ;
		usleep(700000) ;
		printf("\t6\n") ;
		
		if(m_flagDestroy)
			break ;
	}

	printf("Bye~ thFunc_B()\n") ;
	return NULL ;
}

int MyTest_init()
{
	pthread_create(&pthA, NULL, thFunc_A, NULL) ;
	pthread_create(&pthB, NULL, thFunc_B, NULL) ;

	return 1 ;
}

int MyTest_destroy()
{
	m_flagDestroy = 1 ;

	pthread_join(pthA, NULL) ;
	printf("After pthread_join() - A\n") ;
	pthread_join(pthB, NULL) ;
	printf("After pthread_join() - B\n") ;

	return 1 ;
}




#include <vector>

using namespace std;

void permutation(vector<int> vect);

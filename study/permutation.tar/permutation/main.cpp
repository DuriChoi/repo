#include <iostream>
#include <vector>
#include "permutation.h"

using namespace std;

int main(){
	vector<int> v{1, 2, 3, 4, 5};
	permutation(v);

	return 0;
}


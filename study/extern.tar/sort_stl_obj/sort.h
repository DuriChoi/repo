#ifdef __cplusplus
extern "C"{
#endif
void sort(int x[], int size);

#ifdef __cplusplus
}
#endif

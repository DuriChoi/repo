#ifndef _MYTEST_H_
#define _MYTEST_H_

	int MyTest_init() ;
	int MyTest_destroy() ;

#endif
